<div class="modal" tabindex="-1" role="dialog" id="display_post_singleton">
  <div class="modal-dialog modal-lg text-dynamic" role="document">
    <div class="modal-content">
      <div class="modal-header mod-head">
        <h5 class="modal-title">Post Singleton</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mod-body">
        <p>Modal body text goes here.</p>
      </div>
      
    </div>
  </div>
</div>