<div class="btn-group special " role="group" aria-label="Basic example">
						<button type="button" class="btn btn-secondary">Post</button>
						<button type="button" class="btn btn-secondary" >Tagged</button>
						<button type="button" class="btn btn-secondary">Shared</button>
						<button type="button" class="btn btn-secondary">Likes</button>
						<button type="button" class="btn btn-secondary">Friends <small class="text-muted display_friendcount">0</small></button>
					</div>