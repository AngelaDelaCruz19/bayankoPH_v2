<div class="modal" id="modal_friendrequest">
  <div class="modal-dialog modal-lg text-dynamic">
    <div class="modal-content">
      <div class="modal-header mod-head">
        <h4 class="modal-title">Friends</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body mod-body" id="parent_friend">
      <div id="friends_panel">
      	
      </div>
      </div>
    </div>
  </div>
</div>